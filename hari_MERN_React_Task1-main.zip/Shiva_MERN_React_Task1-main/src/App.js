import logo from './logo.svg';
import './App.css';
import React from 'react';
import WordCounter from './components/WordCounter';
function App() {
  return(
    <div className="App"> 
      <WordCounter/>
  </div>
  )
}

export default App;